const cityName = document.getElementById('cityName');
const city_name = document.getElementById('city_name');
const submitBtn =document.getElementById('submitBtn');

const temp_status =document.getElementById('temp_status');
const temp =document.getElementById('temp');

const getInfo = async(event) =>{
    event.preventDefault();   //after submission page not load.
    let cityVal = cityName.value;
    // let url = `api.openweathermap.org/data/2.5/weather?q=pune&appid=a33201d0f485d27dd2a1c024b3673f57`;

    if(cityVal ===""){
        city_name.innerText = `please write the name before search`;
    }else{
        try {
            let url = `https://api.openweathermap.org/data/2.5/weather?q=${cityVal}&units=metrice&appid=a33201d0f485d27dd2a1c024b3673f57`;
            const response = await fetch(url);
            const data = await response.json();
            const arrData = [data];

            temp.innerText = arrData[0].main.temp;
            temp_status.innerText = arrData[0].weather[0].main;

            console.log(data);
        } catch{
        city_name.innerText = `enter write city`;
        }
    }

}
submitBtn.addEventListener('click', getInfo);